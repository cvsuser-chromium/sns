<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 15-6-24
 * Time: 下午3:09
 * @author 郑钟良<zzl@ourstu.com>
 */
return array(
    //模块名
    'name' => 'Core',
    //别名
    'alias' => '系统公共模块',
    //版本号
    'version' => '2.1.0',
    //是否商业模块,1是，0，否
    'is_com' => 0,
    //是否显示在导航栏内？  1是，0否
    'show_nav' => 0,
    //模块描述
    'summary' => '系统核心模块，必不可少，负责核心的处理。',
    //开发者
    'developer' => '嘉兴想天信息科技有限公司',

    'icon' => 'globe',
    //开发者网站
    'website' => 'http://www.ourstu.com'
);